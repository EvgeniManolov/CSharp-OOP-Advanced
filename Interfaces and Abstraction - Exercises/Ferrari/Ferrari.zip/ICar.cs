﻿using System;

public interface ICar
{
    string Brakes();

    string Gas();
}

