﻿using System;

public interface IUnit
{
    string Birthdate { get; }
}

