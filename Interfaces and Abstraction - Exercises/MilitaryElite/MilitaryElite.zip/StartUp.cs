﻿using System;
using System.Collections.Generic;

public class Program
{
    public static void Main(string[] args)
    {
        string input = Console.ReadLine();

        List<ISoldier> army = new List<ISoldier>();

        while (input != "End")
        {
            try
            {
                army.Add(SoldierFactory.ProduceSoldier(input));
            }
            catch (Exception )
            {
              
            }
            input = Console.ReadLine();
        }

        foreach (var soldier in army)
        {
            Console.WriteLine(soldier);
        }
    }
}
