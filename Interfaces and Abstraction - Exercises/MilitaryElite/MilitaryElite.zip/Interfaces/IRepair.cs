﻿using System;

public interface IRepair
{
    string PartName { get; }
    int WorkHours { get; }
}