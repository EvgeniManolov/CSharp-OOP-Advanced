﻿using System;

public class StartUp
{
    public static void Main(string[] args)
    {
        Smartphone smartphone = new Smartphone();
        var phoneNumbers = Console.ReadLine().Split();
        var urls = Console.ReadLine().Split();

        foreach (var number in phoneNumbers)
        {
            Console.WriteLine(smartphone.Call(number));
        }

        foreach (var url in urls)
        {
            Console.WriteLine(smartphone.Browse(url));
        }
    }
}

