﻿using System;

public interface ICallable
{
    string Call(string number);
}

