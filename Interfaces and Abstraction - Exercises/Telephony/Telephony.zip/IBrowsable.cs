﻿using System;

public interface IBrowsable
{
    string Browse(string url);
}

