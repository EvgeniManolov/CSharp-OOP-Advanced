﻿using System;

public interface IUnit
{
    string Id { get; }
}

