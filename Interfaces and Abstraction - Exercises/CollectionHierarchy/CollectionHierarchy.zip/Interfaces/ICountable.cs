﻿using System;

public interface ICountable : IRemovable
{
    int Used { get; }
}

