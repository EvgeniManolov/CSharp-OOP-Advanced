﻿using System;

public interface IRemovable : IAddable
{
    string Remove();
}
