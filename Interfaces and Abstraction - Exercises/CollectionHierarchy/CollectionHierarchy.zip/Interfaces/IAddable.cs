﻿using System;

public interface IAddable
{
    int Add(string str);
}

