﻿using System;

public interface IPrivate : ISoldier
{
    double Salary { get; }
}

