﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Box<T>
{
    private IList<T> list;

    public Box()
    {
        this.list = new List<T>();
    }
    public void Add(T element)
    {
        this.list.Add(element);
    }
    public T Remove()
    {
        if (list.Count>0)
        {
            var remove = list.LastOrDefault();
            list.RemoveAt(list.Count-1);
            return remove;
        }
        else
        {
            return default(T);
        }

        
       
    }

    public int Count
    {
        get
        {
            return list.Count;
        }
    }
}

