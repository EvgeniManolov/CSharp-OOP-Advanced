﻿using System;

class StartUp
{
    static void Main(string[] args)
    {       //Tuple
            // var infoLine = Console.ReadLine().Split();
            // var names = $"{infoLine[0]} {infoLine[1]}";
            // var address = infoLine[2];
            // var namesAndAddress = new Tuple<string, string>(names, address);
            // Console.WriteLine(namesAndAddress);
            //
            // var infoLine2 = Console.ReadLine().Split();
            // var name = infoLine2[0];
            // var liters = int.Parse(infoLine2[1]);
            // var nameAndLiters = new Tuple<string, int>(name, liters);
            // Console.WriteLine(nameAndLiters);
            //
            // var infoLine3 = Console.ReadLine().Split();
            // var someInteger = int.Parse(infoLine3[0]);
            // var someDouble = double.Parse(infoLine3[1]);
            // var intAndDouble = new Tuple<int, double>(someInteger, someDouble);
            // Console.WriteLine(intAndDouble);


        //Threeuple
        var infoLine = Console.ReadLine().Split();
        var names = $"{infoLine[0]} {infoLine[1]}";
        var address = infoLine[2];
        var city = infoLine[3];
        var namesAndAddress = new Tuple<string, string, string>(names, address, city);
        Console.WriteLine(namesAndAddress);

        var infoLine2 = Console.ReadLine().Split();
        var name = infoLine2[0];
        var liters = int.Parse(infoLine2[1]);
        var drunkOrNot = infoLine2[2];
        if (drunkOrNot == "drunk")
        {
            var nameAndLitersAndDrunkOrNot = new Tuple<string, int, string>(name, liters, "True");
            Console.WriteLine(nameAndLitersAndDrunkOrNot);
        }
        else
        {
            var nameAndLitersAndDrunkOrNot = new Tuple<string, int, string>(name, liters, "False");
            Console.WriteLine(nameAndLitersAndDrunkOrNot);
        }

        var infoLine3 = Console.ReadLine().Split();
        var someName = infoLine3[0];
        var someDouble = double.Parse(infoLine3[1]);
        var someString = infoLine3[2];
        var nameAndDoubleAndString = new Tuple<string, double, string>(someName, someDouble, someString);
        Console.WriteLine(nameAndDoubleAndString);
    }
}

